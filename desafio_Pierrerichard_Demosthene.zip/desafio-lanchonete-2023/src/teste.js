import { CaixaDaLanchonete } from "./caixa-da-lanchonete.js";


const caixa = new CaixaDaLanchonete();

console.log(caixa.calcularValorDaCompra('debito', ['chantily,1']));//Item extra não pode ser pedido sem o principal

console.log(caixa.calcularValorDaCompra('debito', ['cafe,1', 'chantily,1']));//R$ 4.50

console.log(caixa.calcularValorDaCompra('credito', ['combo1,1', 'cafe,2']));//R$ 15.96

console.log(caixa.calcularValorDaCompra('debito', [])); // "Não há itens no carrinho de compra!"

console.log(caixa.calcularValorDaCompra('debito', ['cafe', '0'])); // "Quantidade inválida!"

console.log(caixa.calcularValorDaCompra('debito', ['pizza', '1'])); // "Item inválido!"

console.log(caixa.calcularValorDaCompra('cheque', ['cafe', '1'])); // "Forma de pagamento invalido"