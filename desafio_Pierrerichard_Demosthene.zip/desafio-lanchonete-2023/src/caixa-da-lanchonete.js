//consegui  resolver o desafio e validá-lo com arquivo teste.js foi criado.
//basta o rodar o arquivo teste.js para ver os resultados,fiz algumas testes.

// Definição da classe CaixaDaLanchonete
class CaixaDaLanchonete {
  constructor() {
    // Inicialização do cardápio com vários itens e seus valores
    this.cardapio = {
      cafe: { descricao: 'Café', valor: 3.00 },
      chantily: { descricao: 'Chantily (extra do Café)', valor: 1.50 },
      suco: { descricao: 'Suco Natural', valor: 6.20 },
      sanduiche: { descricao: 'Sanduíche', valor: 6.50 },
      queijo: { descricao: 'Queijo (extra do Sanduíche)', valor: 2.00 },
      salgado: { descricao: 'Salgado', valor: 7.25 },
      combo1: { descricao: '1 Suco e 1 Sanduíche', valor: 9.50 },
      combo2: { descricao: '1 Café e 1 Sanduíche', valor: 7.50 }
    };

    // Inicialização das formas de pagamento disponíveis
    this.formasDePagamento = ['debito', 'credito', 'dinheiro'];
  }

  // Método para calcular o valor total da compra com base nos itens e na forma de pagamento
  calcularValorDaCompra(formaDePagamento, itens) {
    // Verifica se a forma de pagamento é válida
    if (!this.formasDePagamento.includes(formaDePagamento))
      return 'Forma de pagamento inválida!';
    
    // Verifica se há itens no carrinho de compra
    if (!itens.length)
      return 'Não há itens no carrinho de compra!';

    // Inicialização do total da compra
    let totalCompra = 0;

    // Itera sobre os itens no carrinho
    for (const itemInfo of itens) {
      // Divide a informação do item em código e quantidade
      const [codigo, quantidade] = itemInfo.split(',');
      
      // Obtém informações do item no cardápio
      const cardapioItem = this.cardapio[codigo];
      if (!cardapioItem)
        return 'Item inválido!';
      
      // Converte a quantidade para um número inteiro
      const parsedQuantidade = parseInt(quantidade);
      if (isNaN(parsedQuantidade) || parsedQuantidade <= 0)
        return 'Quantidade inválida!';

      // Calcula o valor total do item e adiciona ao total da compra
      totalCompra += cardapioItem.valor * parsedQuantidade;
      
      // Verifica se o item é chantily ou queijo e se o item principal está presente
      if (['chantily', 'queijo'].includes(codigo)) {
        const itemPrincipal = codigo === 'chantily' ? 'cafe' : 'sanduiche';
        if (!itens.includes(`${itemPrincipal},${quantidade}`))
          return 'Item extra não pode ser pedido sem o principal';
      }
    }

    // Aplica desconto ou acréscimo com base na forma de pagamento
    if (formaDePagamento === 'dinheiro')
      totalCompra *= 0.95;
    else if (formaDePagamento === 'credito')
      totalCompra *= 1.03;

    // Formata o valor total da compra como uma string e retorna
    return `R$ ${totalCompra.toFixed(2)}`;
  }
}

// Exporta a classe CaixaDaLanchonete para uso em outros arquivos
export { CaixaDaLanchonete };
